package com.msaone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsaoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
