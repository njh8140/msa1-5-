package com.msafive.stock.model;

public class StockVO {
	
	public String stockcd;
	public String stocknm;
	
}