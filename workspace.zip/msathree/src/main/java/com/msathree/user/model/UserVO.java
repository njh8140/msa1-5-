package com.msathree.user.model;

public class UserVO {
	
	public String id;
	public String name;
	
}