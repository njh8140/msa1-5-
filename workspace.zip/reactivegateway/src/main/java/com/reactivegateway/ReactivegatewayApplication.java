package com.reactivegateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactivegatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactivegatewayApplication.class, args);
	}

}
