package com.msafour.prodinfo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.msafour.prodinfo.mapper.ProdinfoMapper;
import com.msafour.prodinfo.model.ProdinfoVO;

@Service
public class ProdinfoService {
	
	@Autowired
	public ProdinfoMapper prodinfoMapper;
	
	public List<ProdinfoVO> getProdinfoList(){
		return prodinfoMapper.selectProdinfoList();
	}
	
	public void saveProdinfo(String prodcd, String prodnm) {
		prodinfoMapper.insertProdinfo(prodcd, prodnm);
	}
	
	public ProdinfoVO getProdinfo(String prodcd) {
		return prodinfoMapper.selectByProdcd(prodcd);
	}
	
	public void deleteProdinfo(String prodcd) {
		prodinfoMapper.deleteProdinfo(prodcd);
	}
	
	public void updateProdinfo(String prodcd, String prodnm) {
		prodinfoMapper.updateProdinfo(prodcd, prodnm);
	}
	
}