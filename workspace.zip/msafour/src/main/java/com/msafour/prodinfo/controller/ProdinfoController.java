package com.msafour.prodinfo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.msafour.prodinfo.model.ProdinfoVO;
import com.msafour.prodinfo.service.ProdinfoService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class ProdinfoController {
	
	@Autowired
	public ProdinfoService prodinfoService;
	
	@RequestMapping(value="/form", method= {RequestMethod.GET, RequestMethod.POST}) //홈페이지용
	public ModelAndView form() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/prodinfo/prodinfoform");
		
		return mav;
	}
	
	@RequestMapping(value="/api/getform", method= {RequestMethod.GET, RequestMethod.POST}) 
	@ResponseBody
	public ProdinfoVO getform(@RequestBody ProdinfoVO uv) {
		ProdinfoVO uv2 = new ProdinfoVO();
		uv2 = prodinfoService.getProdinfo(uv.prodcd);
		
		return uv2;
	}
	
	
	@RequestMapping(value="/api/signup", method= {RequestMethod.GET, RequestMethod.POST}) //api 붙은 것들은 기능
	public void signup(@RequestBody ProdinfoVO uv) {
		System.out.println("prodinfo prodnm ===> "+uv.prodnm);
		System.out.println("prodinfo prodcd ===> "+uv.prodcd);
		prodinfoService.saveProdinfo(uv.prodcd, uv.prodnm);
	}
	
	@RequestMapping(value="/prodinfolist", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView prodinfolist() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/prodinfo/prodinfolist");
		
		return mav;
	}

	@RequestMapping(value="/api/list", method= {RequestMethod.GET, RequestMethod.POST})
	@ResponseBody
	public List<ProdinfoVO> list(){
		List<ProdinfoVO> list = prodinfoService.getProdinfoList();
		
		return list;
		
	}
	
	@RequestMapping(value="/api/update", method= {RequestMethod.GET, RequestMethod.POST}) 
	@ResponseBody
	public void update(@RequestBody ProdinfoVO uv) {
		prodinfoService.updateProdinfo(uv.prodcd, uv.prodnm);
	}
	
	@RequestMapping(value="/api/delete", method= {RequestMethod.GET, RequestMethod.POST}) 
	@ResponseBody
	public void delete(@RequestBody ProdinfoVO uv) {
		prodinfoService.deleteProdinfo(uv.prodcd);
	}
	
	/*@RequestMapping(value="/save", method= {RequestMethod.GET, RequestMethod.POST}) //save 연습
	public ModelAndView save() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/user/usersave");
		
		return mav;}*/
	
}